import GameConfig from "./GameConfig";
import BigRank from "./view/BigRank";
class Main {
	constructor() {
		//设置子域
		Laya.isWXOpenDataContext = true;
		Laya.isWXPosMsg = true;
		//根据IDE设置初始化引擎		
		Laya.init(GameConfig.width, GameConfig.height, false);
		Laya.stage.scaleMode = GameConfig.scaleMode;
		Laya.stage.screenMode = GameConfig.screenMode;
		Laya.stage.alignV = GameConfig.alignV;
		Laya.stage.alignH = GameConfig.alignH;
		if (Laya.Browser.onMiniGame) {
			Laya.Browser.window.wx.onMessage(function (data) {//微信接受信息
				if (data.url == "res/atlas/RankingListAtlas.atlas") {
					Laya.loader.load([
						"res/atlas/RankingListAtlas.atlas"], Laya.Handler.create(this, this.onComplete));
				}
			}.bind(this));
		}
	}

	onComplete(): void {
		//初始化rank排行榜
		var rank = new BigRank();
		//初始化
		rank.init();
	}
}
//激活启动类
new Main();
