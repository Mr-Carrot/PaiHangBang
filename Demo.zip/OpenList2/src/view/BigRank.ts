import { ui } from "../ui/layaMaxUI"
export default class BigRank extends ui.test.ListUI {
    static I: BigRank;
    constructor() {
        super();
        BigRank.I = this;
    }

    /**list初始化使用的数据 */
    private arr: Array<any> = []
    /**list初始化使用的数据{nickName,avatarUrl,value1,value2} */
    private UserData: Array<any> = []
    //榜1
    List1: Array<any> = [];
    //榜2
    List2: Array<any> = [];
    /**
     * 初始化
     */
    public init() {
        Laya.stage.addChild(this);
        console.log(" 初始化");
        if (Laya.Browser.onMiniGame) {
            //接受来自主域的信息
            // 直接展示数据
            // this.getFriendData();       
            this.getData();

        }
        this.CheckRanking.on(Laya.Event.CLICK, this, () => {
            if (!(this.CheckRanking.getChildAt(0) as Laya.Image).visible) {
                (this.CheckRanking.getChildAt(0) as Laya.Image).visible = true;
                (this.LoveRanking.getChildAt(0) as Laya.Image).visible = false;
                Laya.Tween.to(this.lists, { x: 0 }, 500, Laya.Ease.backInOut);
            }

        });
        this.LoveRanking.on(Laya.Event.CLICK, this, () => {
            if (!(this.LoveRanking.getChildAt(0) as Laya.Image).visible) {
                (this.LoveRanking.getChildAt(0) as Laya.Image).visible = true;
                (this.CheckRanking.getChildAt(0) as Laya.Image).visible = false;
                Laya.Tween.to(this.lists, { x: -640 }, 500, Laya.Ease.backInOut);
            }
        });

    }
    //  ["萝卜", 123, 456]
    recevieData2(message): void {
        if (message.type) {
            return;
        }
        console.log(message);
        //判断arr集合中的元素是否存在名字与传送过来的消息的名字相同的值，若存在则删除该值 
        for (let i = 0; i < BigRank.I.UserData.length; i++) {
            const element = BigRank.I.UserData[i];
            if (element.nickName == message[0].nickName) {
                console.log("判断", element.UserName, message[0].nickName);
                console.log(BigRank.I.UserData.length);
                BigRank.I.UserData.splice(i, 1);
                console.log(BigRank.I.UserData.length);
            }
        }
        //在arr集合中添加新的值。
        BigRank.I.UserData.push({ Number: 1, nickName: message[0].nickName, avatarUrl: message[0].avatarUrl, value1: message[1], value2: message[2] });
        //榜1排序
        for (var i = 0; i < BigRank.I.UserData.length - 1; i++) {
            for (var j = i + 1; j < BigRank.I.UserData.length; j++) {
                if (BigRank.I.UserData[i].value1 < BigRank.I.UserData[j].value1) {
                    var data = BigRank.I.UserData[i];
                    BigRank.I.UserData[i] = BigRank.I.UserData[j];
                    BigRank.I.UserData[j] = data;
                }
            }
        }
        //将排序好的集合复制到List1中
        BigRank.I.List1 = [];
        for (let i = 0; i < BigRank.I.UserData.length; i++) {
            const element = BigRank.I.UserData[i];
            element.Number = i + 1;
            BigRank.I.List1.push(element);
        }
        if (BigRank.I.List1.length > 20)
            BigRank.I.List1.splice(19);
        //榜2排序
        for (var i = 0; i < BigRank.I.UserData.length - 1; i++) {
            for (var j = i + 1; j < BigRank.I.UserData.length; j++) {
                if (BigRank.I.UserData[i].value2 < BigRank.I.UserData[j].value2) {
                    var data = BigRank.I.UserData[i];
                    BigRank.I.UserData[i] = BigRank.I.UserData[j];
                    BigRank.I.UserData[j] = data;
                }
            }
        }
        //将排序好的集合复制到List2中
        BigRank.I.List2 = [];
        for (let i = 0; i < BigRank.I.UserData.length; i++) {
            const element = BigRank.I.UserData[i];
            element.Number = i + 1;
            BigRank.I.List2.push(element);
        }
        if (BigRank.I.List2.length > 20)
            BigRank.I.List2.splice(19);
        console.log("榜1", BigRank.I.List1);
        console.log("榜2", BigRank.I.List2);
        BigRank.I.setSelfData2(message);
        BigRank.I.setlist(BigRank.I.List1);
    }

    private getData(): void {
        wx.getFriendCloudStorage({
            keyList: ['test10086'],
            success: function (res) {
                BigRank.I.UserData = [];
                for (let l = 0; l < res.data.length; l++) {
                    const data = res.data[l];
                    console.log(data);
                    console.log(data.nickname, data.avatarUrl, data.KVDataList)
                    var KVdata = JSON.parse(data.KVDataList[0].value)
                    var message = KVdata.wxgame.value;
                    BigRank.I.UserData.push({ nickName: message[0].nickName, avatarUrl: message[0].avatarUrl, value1: message[1], value2: message[2] });
                }
                wx.onMessage(BigRank.I.recevieData2);
            }
        });
    }
    /**
     * 设置list arr
     * @param arr 赋值用的arr
     */
    public setlist(arr): void {
        BigRank.I._list.array = arr;
        BigRank.I._list.refresh();
        BigRank.I._list2.array = arr;
        BigRank.I._list2.refresh();
    }
    public setSelfData2(message): void {
        var kvDataList = [];
        var obj: any = {};
        obj.wxgame = {};
        obj.wxgame.value = message;
        console.log(obj);
        kvDataList.push({ "key": "test10086", "value": JSON.stringify(obj) });
        wx.setUserCloudStorage({
            KVDataList: kvDataList,
            success: function (e) {
                console.log('-----success:' + JSON.stringify(e));
            },
            fail: function (e) {
                console.log('-----fail:' + JSON.stringify(e));
            },
            complete: function (e) {
                console.log('-----complete:' + JSON.stringify(e));
            }
        });

    }
}
