/**
 * 子弹脚本，实现子弹飞行逻辑及对象池回收机制
 */
export default class Bullet extends Laya.Script {
    constructor() { super(); }

}