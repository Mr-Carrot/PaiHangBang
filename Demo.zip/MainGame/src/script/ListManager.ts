export default class ListManager extends Laya.Script {
    constructor() { super(); }
    SendBtn: Laya.Button;
    ShowListBtn: Laya.Sprite;
    static open: Laya.WXOpenDataViewer;
    onEnable(): void {
        console.log("排行榜打开了!");
        ListManager.open = this.owner.getChildByName("open") as Laya.WXOpenDataViewer;
        var w: any = wx;
        w.getUserInfo({
            success(res) {
                console.log("Success", res);
                ListManager.open.postMsg([res.userInfo, 123, 456]);
            }
            , fail(e) {
                console.log(e);
            }
        })
    }

}