(function () {
    'use strict';

    class ListManager extends Laya.Script {
        constructor() { super(); }
        onEnable() {
            console.log("排行榜打开了!");
            ListManager.open = this.owner.getChildByName("open");
            var w = wx;
            w.getUserInfo({
                success(res) {
                    console.log("Success", res);
                    ListManager.open.postMsg([res.userInfo, 123, 456]);
                },
                fail(e) {
                    console.log(e);
                }
            });
        }
    }

    var REG = Laya.ClassUtils.regClass;
    var ui;
    (function (ui) {
        var test;
        (function (test) {
            class TestSceneUI extends Laya.Scene {
                constructor() { super(); }
                createChildren() {
                    super.createChildren();
                    this.loadScene("test/TestScene");
                }
            }
            test.TestSceneUI = TestSceneUI;
            REG("ui.test.TestSceneUI", TestSceneUI);
        })(test = ui.test || (ui.test = {}));
    })(ui || (ui = {}));

    class GameUI extends ui.test.TestSceneUI {
        constructor() {
            super();
        }
        onEnable() {
            GameUI.I = this;
            console.log("获取用户信息");
            if (Laya.Browser.onMiniGame) {
                var w = wx;
                var Item = Laya.LocalStorage.getItem("获取用户信息");
                if (Item) {
                    w.getSetting({
                        success(res) {
                            console.log(res.authSetting);
                            if (!res.authSetting) {
                                let button = w.createUserInfoButton({
                                    type: 'text',
                                    text: '获取用户信息',
                                    style: {
                                        left: 10,
                                        top: 76,
                                        width: 200,
                                        height: 40,
                                        lineHeight: 40,
                                        backgroundColor: '#ff0000',
                                        color: '#ffffff',
                                        textAlign: 'center',
                                        fontSize: 16,
                                        borderRadius: 4
                                    }
                                });
                                button.onTap((res) => {
                                    console.log(res);
                                    Laya.LocalStorage.setItem("获取用户信息", "获取用户信息");
                                    button.destroy();
                                    Laya.Scene.open("test/List.json");
                                });
                            }
                            else {
                                GameUI.I.OpenView.on(Laya.Event.CLICK, this, () => {
                                    Laya.Scene.open("test/List.json");
                                });
                            }
                        }
                    });
                }
                else {
                    let button = w.createUserInfoButton({
                        type: 'text',
                        text: '获取用户信息',
                        style: {
                            left: 10,
                            top: 76,
                            width: 200,
                            height: 40,
                            lineHeight: 40,
                            backgroundColor: '#ff0000',
                            color: '#ffffff',
                            textAlign: 'center',
                            fontSize: 16,
                            borderRadius: 4
                        }
                    });
                    button.onTap((res) => {
                        console.log(res);
                        button.destroy();
                        Laya.Scene.open("test/List.json");
                        Laya.LocalStorage.setItem("获取用户信息", "获取用户信息");
                    });
                }
            }
            else {
                this.OpenView.on(Laya.Event.CLICK, this, () => {
                    Laya.Scene.open("test/List.json");
                });
            }
        }
    }

    class GameControl extends Laya.Script {
        constructor() { super(); }
    }

    class Bullet extends Laya.Script {
        constructor() { super(); }
    }

    class DropBox extends Laya.Script {
        constructor() { super(); }
    }

    class GameConfig {
        constructor() { }
        static init() {
            var reg = Laya.ClassUtils.regClass;
            reg("script/ListManager.ts", ListManager);
            reg("script/GameUI.ts", GameUI);
            reg("script/GameControl.ts", GameControl);
            reg("script/Bullet.ts", Bullet);
            reg("script/DropBox.ts", DropBox);
        }
    }
    GameConfig.width = 640;
    GameConfig.height = 1136;
    GameConfig.scaleMode = "fixedwidth";
    GameConfig.screenMode = "none";
    GameConfig.alignV = "top";
    GameConfig.alignH = "left";
    GameConfig.startScene = "test/TestScene.scene";
    GameConfig.sceneRoot = "";
    GameConfig.debug = false;
    GameConfig.stat = false;
    GameConfig.physicsDebug = false;
    GameConfig.exportSceneToJson = true;
    GameConfig.init();

    class Main {
        constructor() {
            if (window["Laya3D"])
                Laya3D.init(GameConfig.width, GameConfig.height);
            else
                Laya.init(GameConfig.width, GameConfig.height, Laya["canvas"]);
            Laya["Physics"] && Laya["Physics"].enable();
            Laya["DebugPanel"] && Laya["DebugPanel"].enable();
            Laya.stage.scaleMode = GameConfig.scaleMode;
            Laya.stage.screenMode = GameConfig.screenMode;
            Laya.stage.alignV = GameConfig.alignV;
            Laya.stage.alignH = GameConfig.alignH;
            Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;
            if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true")
                Laya.enableDebugPanel();
            if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"])
                Laya["PhysicsDebugDraw"].enable();
            if (GameConfig.stat)
                Laya.Stat.show();
            Laya.alertGlobalError = true;
            if (Laya.Browser.onMiniGame) {
                Laya.loader.load(["res/atlas/RankingListAtlas.atlas"], Laya.Handler.create(this, () => {
                    Laya.MiniAdpter.sendAtlasToOpenDataContext("res/atlas/RankingListAtlas.atlas");
                }));
            }
            Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION);
        }
        onVersionLoaded() {
            Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded));
        }
        onConfigLoaded() {
            GameConfig.startScene && Laya.Scene.open(GameConfig.startScene);
        }
    }
    new Main();

}());
