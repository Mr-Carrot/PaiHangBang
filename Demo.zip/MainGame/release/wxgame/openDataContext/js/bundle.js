(function () {
  'use strict';

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0

  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.

  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */
  /* global Reflect, Promise */

  var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
      return extendStatics(d, b);
  };

  function __extends(d, b) {
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }

  var REG = Laya.ClassUtils.regClass;
  var ui;
  (function (ui) {
      var test;
      (function (test) {
          var BigItemUI = (function (_super) {
              __extends(BigItemUI, _super);
              function BigItemUI() {
                  return _super.call(this) || this;
              }
              BigItemUI.prototype.createChildren = function () {
                  _super.prototype.createChildren.call(this);
                  this.createView(BigItemUI.uiView);
              };
              BigItemUI.uiView = { "type": "View", "props": { "width": 580, "height": 100 }, "compId": 2, "child": [{ "type": "Sprite", "props": { "y": -1, "x": 19.5, "texture": "RankingListAtlas/rankinglist_bar.png" }, "compId": 7 }, { "type": "Image", "props": { "y": 6, "x": 108, "width": 80, "var": "img_head", "height": 80 }, "compId": 3, "child": [{ "type": "Sprite", "props": { "y": -1, "x": -1, "width": 82, "renderType": "mask", "height": 82 }, "compId": 10 }] }, { "type": "Label", "props": { "y": 38.5, "x": 173, "width": 259, "var": "text_name", "text": "名字", "overflow": "scroll", "height": 24, "fontSize": 20, "font": "Microsoft YaHei", "color": "#ffffff", "align": "center" }, "compId": 4 }, { "type": "Label", "props": { "y": 42.5, "x": 474, "var": "text_score", "text": "分数", "fontSize": 20, "color": "#ffffff", "align": "center" }, "compId": 5 }, { "type": "Sprite", "props": { "y": 31, "x": 420, "width": 44, "var": "love", "texture": "RankingListAtlas/icon_shell.png", "height": 38 }, "compId": 11 }, { "type": "Label", "props": { "y": -2, "x": 48, "width": 51, "var": "Number", "valign": "middle", "text": "1", "height": 92, "fontSize": 50, "font": "SimHei", "color": "#ffffff", "bold": true, "align": "center" }, "compId": 12 }], "loadList": ["RankingListAtlas/rankinglist_bar.png", "RankingListAtlas/icon_shell.png"], "loadList3D": [] };
              return BigItemUI;
          }(Laya.View));
          test.BigItemUI = BigItemUI;
          REG("ui.test.BigItemUI", BigItemUI);
          var ListUI = (function (_super) {
              __extends(ListUI, _super);
              function ListUI() {
                  return _super.call(this) || this;
              }
              ListUI.prototype.createChildren = function () {
                  _super.prototype.createChildren.call(this);
                  this.createView(ListUI.uiView);
              };
              ListUI.uiView = { "type": "View", "props": { "width": 640, "height": 1136 }, "compId": 2, "child": [{ "type": "Sprite", "props": { "y": 0, "x": 0, "var": "lists" }, "compId": 22, "child": [{ "type": "List", "props": { "y": 120, "x": 642, "width": 640, "var": "_list2", "vScrollBarSkin": " ", "spaceY": 0, "repeatX": 1, "height": 745, "elasticEnabled": true }, "compId": 12, "child": [{ "type": "bigItem", "props": { "y": 6, "x": 30, "runtime": "view/BigItem2.ts", "renderType": "render" }, "compId": 18 }] }, { "type": "List", "props": { "y": 120, "x": 0, "width": 640, "var": "_list", "vScrollBarSkin": " ", "spaceY": 0, "repeatX": 1, "height": 754, "elasticEnabled": true }, "compId": 13, "child": [{ "type": "bigItem", "props": { "y": 6, "x": 30, "runtime": "view/bigItem.ts", "renderType": "render" }, "compId": 19 }] }] }, { "type": "Image", "props": { "y": 0, "x": 0, "visible": true, "var": "CheckRanking", "skin": "RankingListAtlas/button_stagelist_d.png" }, "compId": 20, "child": [{ "type": "Image", "props": { "y": 0, "x": 0, "width": 247, "visible": true, "skin": "RankingListAtlas/button_stagelist_l.png", "height": 106 }, "compId": 16 }, { "type": "Label", "props": { "y": 0, "x": 0, "width": 249, "valign": "middle", "text": "榜1", "height": 108, "fontSize": 50, "bold": true, "align": "center" }, "compId": 37 }] }, { "type": "Image", "props": { "y": 53, "x": 642, "width": 247, "visible": true, "var": "LoveRanking", "skin": "RankingListAtlas/button_shelllist_d.png", "pivotY": 53, "pivotX": 247, "height": 106 }, "compId": 21, "child": [{ "type": "Image", "props": { "y": 53, "x": 247, "width": 247, "visible": false, "skin": "RankingListAtlas/button_shelllist_l.png", "pivotY": 53, "pivotX": 247, "height": 106 }, "compId": 17 }, { "type": "Label", "props": { "y": 0, "x": 0, "width": 249, "valign": "middle", "text": "榜2", "height": 108, "fontSize": 50, "bold": true, "align": "center" }, "compId": 38 }] }, { "type": "Sprite", "props": { "y": 97, "x": 2, "texture": "RankingListAtlas/rankinglist_line.png" }, "compId": 35 }, { "type": "Sprite", "props": { "y": 861.5, "x": 0, "width": 640, "texture": "RankingListAtlas/rankinglist_line.png", "rotation": 0, "height": 25 }, "compId": 36 }], "loadList": ["RankingListAtlas/button_stagelist_d.png", "RankingListAtlas/button_stagelist_l.png", "RankingListAtlas/button_shelllist_d.png", "RankingListAtlas/button_shelllist_l.png", "RankingListAtlas/rankinglist_line.png"], "loadList3D": [] };
              return ListUI;
          }(Laya.View));
          test.ListUI = ListUI;
          REG("ui.test.ListUI", ListUI);
      })(test = ui.test || (ui.test = {}));
  })(ui || (ui = {}));

  var BigItem = (function (_super) {
      __extends(BigItem, _super);
      function BigItem() {
          return _super.call(this) || this;
      }
      Object.defineProperty(BigItem.prototype, "dataSource", {
          set: function (value) {
              if (!value)
                  return;
              this.img_head.skin = value.avatarUrl;
              this.text_name.text = value.nickName;
              this.text_score.text = value.value2;
              this.love.visible = true;
          },
          enumerable: true,
          configurable: true
      });
      return BigItem;
  }(ui.test.BigItemUI));

  var BigItem$1 = (function (_super) {
      __extends(BigItem, _super);
      function BigItem() {
          return _super.call(this) || this;
      }
      Object.defineProperty(BigItem.prototype, "dataSource", {
          set: function (value) {
              if (!value)
                  return;
              this.img_head.skin = value.avatarUrl;
              this.text_name.text = value.nickName;
              this.text_score.text = value.value1;
              this.love.visible = false;
              this.Number.text = "" + value.Number;
          },
          enumerable: true,
          configurable: true
      });
      return BigItem;
  }(ui.test.BigItemUI));

  var GameConfig = (function () {
      function GameConfig() {
      }
      GameConfig.init = function () {
          var reg = Laya.ClassUtils.regClass;
          reg("view/BigItem2.ts", BigItem);
          reg("view/bigItem.ts", BigItem$1);
      };
      GameConfig.width = 640;
      GameConfig.height = 1136;
      GameConfig.scaleMode = "fixedwidth";
      GameConfig.screenMode = "none";
      GameConfig.alignV = "top";
      GameConfig.alignH = "left";
      GameConfig.startScene = "test/List.scene";
      GameConfig.sceneRoot = "";
      GameConfig.debug = false;
      GameConfig.stat = false;
      GameConfig.physicsDebug = false;
      GameConfig.exportSceneToJson = true;
      return GameConfig;
  }());
  GameConfig.init();

  var BigRank = (function (_super) {
      __extends(BigRank, _super);
      function BigRank() {
          var _this = _super.call(this) || this;
          _this.arr = [];
          _this.UserData = [];
          _this.List1 = [];
          _this.List2 = [];
          BigRank.I = _this;
          return _this;
      }
      BigRank.prototype.init = function () {
          var _this = this;
          Laya.stage.addChild(this);
          console.log(" 初始化");
          if (Laya.Browser.onMiniGame) {
              this.getData();
          }
          this.CheckRanking.on(Laya.Event.CLICK, this, function () {
              if (!_this.CheckRanking.getChildAt(0).visible) {
                  _this.CheckRanking.getChildAt(0).visible = true;
                  _this.LoveRanking.getChildAt(0).visible = false;
                  Laya.Tween.to(_this.lists, { x: 0 }, 500, Laya.Ease.backInOut);
              }
          });
          this.LoveRanking.on(Laya.Event.CLICK, this, function () {
              if (!_this.LoveRanking.getChildAt(0).visible) {
                  _this.LoveRanking.getChildAt(0).visible = true;
                  _this.CheckRanking.getChildAt(0).visible = false;
                  Laya.Tween.to(_this.lists, { x: -640 }, 500, Laya.Ease.backInOut);
              }
          });
      };
      BigRank.prototype.recevieData2 = function (message) {
          if (message.type) {
              return;
          }
          console.log(message);
          for (var i_1 = 0; i_1 < BigRank.I.UserData.length; i_1++) {
              var element = BigRank.I.UserData[i_1];
              if (element.nickName == message[0].nickName) {
                  console.log("判断", element.UserName, message[0].nickName);
                  console.log(BigRank.I.UserData.length);
                  BigRank.I.UserData.splice(i_1, 1);
                  console.log(BigRank.I.UserData.length);
              }
          }
          BigRank.I.UserData.push({ Number: 1, nickName: message[0].nickName, avatarUrl: message[0].avatarUrl, value1: message[1], value2: message[2] });
          for (var i = 0; i < BigRank.I.UserData.length - 1; i++) {
              for (var j = i + 1; j < BigRank.I.UserData.length; j++) {
                  if (BigRank.I.UserData[i].value1 < BigRank.I.UserData[j].value1) {
                      var data = BigRank.I.UserData[i];
                      BigRank.I.UserData[i] = BigRank.I.UserData[j];
                      BigRank.I.UserData[j] = data;
                  }
              }
          }
          BigRank.I.List1 = [];
          for (var i_2 = 0; i_2 < BigRank.I.UserData.length; i_2++) {
              var element = BigRank.I.UserData[i_2];
              element.Number = i_2 + 1;
              BigRank.I.List1.push(element);
          }
          if (BigRank.I.List1.length > 20)
              BigRank.I.List1.splice(19);
          for (var i = 0; i < BigRank.I.UserData.length - 1; i++) {
              for (var j = i + 1; j < BigRank.I.UserData.length; j++) {
                  if (BigRank.I.UserData[i].value2 < BigRank.I.UserData[j].value2) {
                      var data = BigRank.I.UserData[i];
                      BigRank.I.UserData[i] = BigRank.I.UserData[j];
                      BigRank.I.UserData[j] = data;
                  }
              }
          }
          BigRank.I.List2 = [];
          for (var i_3 = 0; i_3 < BigRank.I.UserData.length; i_3++) {
              var element = BigRank.I.UserData[i_3];
              element.Number = i_3 + 1;
              BigRank.I.List2.push(element);
          }
          if (BigRank.I.List2.length > 20)
              BigRank.I.List2.splice(19);
          console.log("榜1", BigRank.I.List1);
          console.log("榜2", BigRank.I.List2);
          BigRank.I.setSelfData2(message);
          BigRank.I.setlist(BigRank.I.List1);
      };
      BigRank.prototype.getData = function () {
          wx.getFriendCloudStorage({
              keyList: ['test10086'],
              success: function (res) {
                  BigRank.I.UserData = [];
                  for (var l = 0; l < res.data.length; l++) {
                      var data = res.data[l];
                      console.log(data);
                      console.log(data.nickname, data.avatarUrl, data.KVDataList);
                      var KVdata = JSON.parse(data.KVDataList[0].value);
                      var message = KVdata.wxgame.value;
                      BigRank.I.UserData.push({ nickName: message[0].nickName, avatarUrl: message[0].avatarUrl, value1: message[1], value2: message[2] });
                  }
                  wx.onMessage(BigRank.I.recevieData2);
              }
          });
      };
      BigRank.prototype.setlist = function (arr) {
          BigRank.I._list.array = arr;
          BigRank.I._list.refresh();
          BigRank.I._list2.array = arr;
          BigRank.I._list2.refresh();
      };
      BigRank.prototype.setSelfData2 = function (message) {
          var kvDataList = [];
          var obj = {};
          obj.wxgame = {};
          obj.wxgame.value = message;
          console.log(obj);
          kvDataList.push({ "key": "test10086", "value": JSON.stringify(obj) });
          wx.setUserCloudStorage({
              KVDataList: kvDataList,
              success: function (e) {
                  console.log('-----success:' + JSON.stringify(e));
              },
              fail: function (e) {
                  console.log('-----fail:' + JSON.stringify(e));
              },
              complete: function (e) {
                  console.log('-----complete:' + JSON.stringify(e));
              }
          });
      };
      return BigRank;
  }(ui.test.ListUI));

  var Main = (function () {
      function Main() {
          Laya.isWXOpenDataContext = true;
          Laya.isWXPosMsg = true;
          Laya.init(GameConfig.width, GameConfig.height, false);
          Laya.stage.scaleMode = GameConfig.scaleMode;
          Laya.stage.screenMode = GameConfig.screenMode;
          Laya.stage.alignV = GameConfig.alignV;
          Laya.stage.alignH = GameConfig.alignH;
          if (Laya.Browser.onMiniGame) {
            Laya.Browser.window.wx.onMessage(function (data) {
              if (data.url == "res/atlas/RankingListAtlas.atlas") {
                console.log("+++++++++++++++++++++++++++++++++++++++++++++++")
                      Laya.loader.load([
                          "res/atlas/RankingListAtlas.atlas"
                      ], Laya.Handler.create(this, this.onComplete));
                  }
              }.bind(this));
          }
      }
      Main.prototype.onComplete = function () {
          var rank = new BigRank();
          rank.init();
      };
      return Main;
  }());
  new Main();

}());
